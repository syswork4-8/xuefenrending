from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import *
import os

from django.db.models import Q
# Create your views here.
def addApplication(request):
    print('c')
    return render(request, 'myApp/addApplication.html')

def addApplicationForm(request):
    print('a')
    print(request.POST)
    if request.method == 'POST':

        temp_Sid = request.POST['Sid']
        temp_Sname = request.POST['Sname']
        temp_Pname = request.POST['Pname']
        temp_Plevel = request.POST['Plevel']
        temp_Pscore = request.POST['Pscore']
        obj = request.FILES.get('Anote')
        Anote = obj
        temp_state = request.POST['state']
        temp_Application = Application(Sid=temp_Sid, Sname=temp_Sname,Pname=temp_Pname,Plevel=temp_Plevel,Pscore=temp_Pscore, Anote=obj,state=temp_state)
        result = temp_Application.save()

        f = open(os.path.join('upload', obj.name), 'wb')
        for line in obj.chunks():
            f.write(line)
        f.close()

        return render(request, 'myApp/succ.html')

def addyiyi(request):
    print('c')
    return render(request, 'myApp/yiyi.html')

def addyiyiForm(request):

    if request.method == 'POST':
        temp_Sid = request.POST['Sid']
        temp_Sname = request.POST['Sname']
        temp_Pname = request.POST['Pname']
        temp_Plevel = request.POST['Plevel']
        temp_Anote = request.POST['Anote']
        temp_Pscore = request.POST['Pscore']
        temp_state = request.POST['state']
        temp_Application = Application(Sid=temp_Sid, Sname=temp_Sname, Pname=temp_Pname, Plevel=temp_Plevel,
                                       Pscore=temp_Pscore, Anote=temp_Anote, state=temp_state)
        result = temp_Application.save()
        return render(request, 'myApp/succ.html')
def stuindex(request):
    print('c')
    return render(request, 'myApp/stuindex.html')



def appxq(request,id):  # 显示学生和奖项信息
    app = Application.objects.get(id=id)
    i = id
    j = app.Sid
    stu = Student.objects.get(Sid=app.Sid)
    apps = {
            'id': app.id,
            'sid': app.Sid,
            'sch': stu.Sschool,
            'scla': stu.Sclass,
            'pna': app.Pname,
            'ple': app.Plevel,
            'psc': app.Pscore,
            'pnote': app.Anote,
            }

    if request.method == 'POST':
        a = request.POST['yz']
        if a == '1':
            x = int(app.Pscore) + int(stu.Sscore)
            print(x)
            q = Application.objects.get(id = i)  # 已通过
            q.state = "已通过"
            q.save()
            p = Student.objects.get(Sid = j)
            p.Sscore = x
            p.save()

            return render(request, 'myApp/succ.html')
        if a == '2':
            q = Application.objects.get(id=i)  # 驳回
            q.state = "被驳回"
            q.save()
            return render(request, 'myApp/succ.html')
    return render(request, 'myApp/appxq.html', apps)


from django.shortcuts import render
from django import forms
from django.http import HttpResponse, HttpResponseRedirect
from .models import Student, Application, Record
import datetime
from django.http import StreamingHttpResponse

"""
def application(request):
    # con = request.session['Sid']
    app = Application.objects.all()
    for i in app:
        stu = Student.object.get(Sid=i.Sid)
        apps[0] = {'sid': i.Sid,
                'pname': i.Pname,
                'sch': stu.Sschool,
                'ple': i.Plevel,
                'state': i.state}
    return render(request, 'myApp/application.html', apps)
"""

def student(request):
    studentList = Student.objects.all()
    return render(request, 'myApp/student.html', {'student': studentList})


def checkRecord(request):
    # 获得对应的审核对象
    check = Application.objects.get()
    # 获得审核对象下的所有状态对象列表
    checkList = check.state_set.all()
    return render(request, 'myApp/application.html', {"application": checkList})


def application(request):
    #con = request.session['susername']
    con = 1
    apps = Application.objects.filter(Sid=con)
    return render(request, 'myApp/application.html',{'apps':apps})


def application_tea(request):
    apps = Application.objects.filter(~Q(state='被驳回')).exclude(state='已通过')
    return render(request, 'myApp/application_tea.html',{'apps':apps})
