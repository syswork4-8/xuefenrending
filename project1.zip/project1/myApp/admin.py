from django.contrib import admin

# Register your models here.
from .models import Student, Application, School, Teacher, Record
admin.site.register(Student)
admin.site.register(Application)
admin.site.register(School)
admin.site.register(Teacher)
admin.site.register(Record)
