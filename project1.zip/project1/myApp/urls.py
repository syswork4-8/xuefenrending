from django.conf.urls import url

from django.contrib import admin
from django.conf.urls import *
from django.urls import path,re_path
from django.conf import settings

from . import views

urlpatterns = [

    url(r'^$', views.header),
    url(r'^header', views.header),
    url(r'^application/$', views.application),
    url(r'^student/$', views.student),
    url(r'^application/(\d+)$', views.application)

]
