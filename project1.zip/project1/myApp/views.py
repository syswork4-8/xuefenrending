from django.shortcuts import render
from django import forms
from django.http import HttpResponse, HttpResponseRedirect
from .models import Student, Application, Record
import datetime
from django.http import StreamingHttpResponse


def test(request):
    return HttpResponse("学分认定管理系统")


def header(request):
    return render(request, 'myApp/header.html')


def application(request):
    con = request.session['Sid']
    app = Application.objects.get(Sid=con)
    apps = {'Sname': app.Sname,
            'Pname': app.Pname,
            'Plevel': app.Plevel,
            'state': app.state}
    return render(request, 'myApp/application.html', apps)


def student(request):
    studentList = Student.objects.all()
    return render(request, 'myApp/student.html', {'student': studentList})


def checkRecord(request):
    # 获得对应的审核对象
    check = Application.objects.get()
    # 获得审核对象下的所有状态对象列表
    checkList = check.state_set.all()
    return render(request, 'myApp/application.html', {"application": checkList})






