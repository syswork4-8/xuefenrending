from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import *
import os
from django.template.loader import get_template
from django.http import HttpResponse
from django.db.models import Q
from django.shortcuts import render,render_to_response

def login(request):
    return render(request, 'myApp/login.html')


def stu_login(request):
    if request.method == "POST":
        uid = request.POST['Sid']
        password = request.POST['psword']
        userResult = Student.objects.filter(Sid=uid, Spsword=password)
        if (len(userResult)>0):
            request.session['sid'] = uid
            stu = Student.objects.get(Sid=uid)
            user = {
                'username':stu.Sname,
                'userscore':stu.Sscore,
                }
            return render(request, 'myApp/stuindex.html', user)
        else:
            return render(request, 'myApp/login.html', {'ctx': "用户名或密码错误"})

    return render(request, 'myApp/login.html')


def addApplication(request):
    con = request.session['sid']
    stu = Student.objects.get(Sid=con)
    stu = {
        'Sid': stu.Sid,
        'Sname': stu.Sname,
        'username': stu.Sname,
        'userscore': stu.Sscore,
    }

    return render(request, 'myApp/addApplication.html', stu)


def addApplicationForm(request):
    print('a')
    con = request.session['sid']
    stu = Student.objects.get(Sid=con)
    user = {
        'username': stu.Sname,
        'userscore': stu.Sscore,
    }
    print(request.POST)
    if request.method == 'POST':

        temp_Sid = stu.Sid
        temp_Sname = stu.Sname
        temp_Pname = request.POST['Pname']
        temp_Plevel = request.POST['Plevel']
        temp_Pscore = request.POST['Pscore']
        obj = request.FILES.get('Anote')
        Anote = obj
        temp_state = request.POST['state']
        temp_Application = Application(Sid=temp_Sid, Sname=temp_Sname,Pname=temp_Pname,Plevel=temp_Plevel,Pscore=temp_Pscore, Anote=obj,state=temp_state)
        result = temp_Application.save()

        f = open(os.path.join('upload', obj.name), 'wb')
        for line in obj.chunks():
            f.write(line)
        f.close()

        return render(request, 'myApp/succ.html',user)


def addyiyi(request, id):
    app = Application.objects.get(id=id)

    apps = {
        'Sid': app.Sid,
        'Sname': app.Sname,
        'Pname': app.Pname,
        'username': stu.Sname,
        'userscore': stu.Sscore,
    }
    if request.method == 'POST':
        obj = request.FILES.get('Anote')
        q = Application.objects.get(id=id)
        q.Pname = request.POST['Pname']
        q.Pscore = request.POST['Pscore']
        q.Plevel = request.POST['Plevel']
        q.state = "有异议"
        q.Anote = obj
        q.save()

        f = open(os.path.join('upload', obj.name), 'wb')
        for line in obj.chunks():
            f.write(line)
        f.close()
        return render(request, 'myApp/succ.html',apps)

    return render(request, 'myApp/yiyi.html', apps)


def stuindex(request):
    con = request.session['sid']
    stu = Student.objects.get(Sid=con)
    user = {
        'username': stu.Sname,
        'userscore': stu.Sscore,
    }
    print('c')
    return render(request, 'myApp/stuindex.html',user)


def appxq(request,id):  # 显示学生和奖项信息
    con = request.session['tid']
    tea = Teacher.objects.get(Tid=con)
    app = Application.objects.get(id=id)
    i = id
    j = app.Sid
    stu = Student.objects.get(Sid=app.Sid)
    apps = {
            'id': app.id,
            'sid': app.Sid,
            'sch': stu.Sschool,
            'scla': stu.Sclass,
            'pna': app.Pname,
            'ple': app.Plevel,
            'psc': app.Pscore,
            'pnote': app.Anote,
            'username': tea.Tname,
            }
    if request.method == 'POST':
        a = request.POST['yz']
        if a == '1':
            x = int(app.Pscore) + int(stu.Sscore)
            print(x)
            q = Application.objects.get(id = i)  # 已通过
            q.state = "已通过"
            q.save()
            p = Student.objects.get(Sid = j)
            p.Sscore = x
            p.save()
            return render(request, 'myApp/succ.html',apps)
        if a == '2':
            q = Application.objects.get(id=i)  # 驳回
            q.state = "被驳回"
            q.save()
            return render(request, 'myApp/succ.html')
    return render(request, 'myApp/appxq.html', apps)


from django.shortcuts import render
from django import forms
from django.http import HttpResponse, HttpResponseRedirect
from .models import Student, Application, Record
import datetime
from django.http import StreamingHttpResponse


def application(request):
    con = request.session['sid']
    apps = Application.objects.filter(Sid=con)
    return render(request, 'myApp/application.html',{'apps':apps})


def application_tea(request):
    apps = Application.objects.filter(~Q(state='被驳回')).exclude(state='已通过')
    con = request.session['sid']
    stu = Student.objects.get(Sid=con)
    #print('----')
    #print(con)
    #print(apps)
    # print(apps.id)
    app1 = []
    for i in apps:
        a = {
        'id': i.id,
        'Pname': i.Pname,
        'Pscore': i.Pscore,
        'Plevel': i.Plevel,
        "state": i.state,
        'username': stu.Sname,
        'userscore': stu.Sscore,
        }
        app1.append(a)

    return render(request, 'myApp/application_tea.html',{'apps':app1})
