#！/usr/bin/env python
# _*_ coding:utf-8 _*_
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import *
import os
from django.template.loader import get_template
from django.http import HttpResponse
from django.db.models import Q
from django.shortcuts import render,render_to_response


def my_render(request, template, user={}):
    con = request.session['sid']
    stu = Student.objects.get(Sid=con)
    user['username'] = stu.Sname
    user['userscore'] = stu.Sscore
    return  render_to_response(template, user)